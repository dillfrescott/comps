#pragma once

#include <cstdint>

uint32_t bitCount(uint32_t v);
